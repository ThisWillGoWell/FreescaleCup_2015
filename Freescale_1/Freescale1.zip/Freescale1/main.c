/*
 * Main Method for testing the PWM Code for the K64F
 * PWM signal can be connected to output pins are PC3 and PC4
 * 
 * Author:William Gowell	  
 * Created: 10/16/2015	  
 * Modified: 10/16/2015  
 */

#include "MK64F12.h"
#include "PWM.h"
#include "UART.h"
#include "stdio.h"
#include "math.h"

#define AVERAGE_WINDOW 5
#define NUM_PIXELS 128

void initialize(void);
void en_interrupts(void);
void delay(int del);
int map(int x, int in_min, int in_max, int out_min, int out_max);	
void averageLine();
void process();
void derivative();

uint16_t* raw_line;
uint16_t line[NUM_PIXELS];
uint16_t derivative_line[NUM_PIXELS];


char str[100];
int j;
int i;

int temp;

char ch;
double weights [AVERAGE_WINDOW] = {0.4, 0.2, 0.2, 0.1, 0.1};


int main(void)
{
	// Initialize UART and PWM
	
	
	initialize();
	
	raw_line = getCameraArray();
	// Print welcome over serial
	

	
	SetDutyCycleMotor(LEFT_MOTOR,50);
	SetDutyCycleMotor(RIGHT_MOTOR,0);
	
	//Step 3
	//Generate 20% duty cycle at 10kHz
	
	
	//Step 9
	for(;;)  //loop forever
	{
		
					
		uart_getchar();
		process();
		for(j=0;j<NUM_PIXELS;j++)
		{
			putByte(line[j]>>4);
		}	
	

		

	}
	return 0;
}

int map(int x, int in_min, int in_max, int out_min, int out_max)
{
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}


/**
 * Waits for a delay (in milliseconds)
 * 
 * del - The delay in milliseconds
 */
void delay(int del){

	for (i=0; i<del*50000; i++){
		// Do nothing
	}
}

void initialize()
{
	// Initialize the FlexTimer
	uart_init();
	InitPWM();
	
}


void process()
{	
	averageLine();
	derivative();
}

void averageLine()
{
	for(i=AVERAGE_WINDOW/2 + 1;i<128 - AVERAGE_WINDOW/2 ;i++)
	{
			line[i] = weights[0] * raw_line[i] + weights[1] * raw_line[i-1] + weights[2] * raw_line[i+1] + weights[3] * raw_line[i-2] + weights[4] * raw_line[i+2];
	}
}

void derivative()
{

	for(i=AVERAGE_WINDOW/2 + 2;i<128 - AVERAGE_WINDOW/2 ;i++)
	{

			derivative_line[i] = line[i]-line[i-1];
	}
}
