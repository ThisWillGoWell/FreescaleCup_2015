#ifndef PMW_H_
#define PMW_H_
#include "MK64F12.h"

#define FORWARD 1
#define BACKWARD 0

#define LEFT_MOTOR 0
#define RIGHT_MOTOR 1

void SetDutyCycleMotor(unsigned int motorNum, unsigned int DutyCycle);
void SetDutyCycleServo(unsigned int pos);
void InitPWM(void);
void PWM_ISR(void);

uint16_t* getCameraArray(void);

#endif /* PWM_H_ */
