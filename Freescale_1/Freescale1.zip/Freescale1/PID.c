struct PID_Data{
	struct{
		double uc; //Setpoint
		double y;	//Measured variable
		double u;	//Controller output
		double v;	//Limited Controller output
	}Signals;

	struct  
	{
		double I;		//Intergral Part
		double D;		//Derivative Part
		double yold;	//Delayed measure variable

	}States;

	struct 
	{
		double K;	//Controller Gain
		double Ti; 	//Intergral time
		double Td;  //Derivative time
		double Tt;	//Reset Time
		double N;	//Maximum derivative gain
		double b;	//Fraction of setpoint in prop. term
		double ulow; //Low output limit
		double uhigh; //High Output Limit
		double h;	//Sampling period
		double bi, ar, bd, ad;
	} Par;
} pid_data;

void PID_Init(struct PID_Data *data)
{
	data->States.I = 0;
	data->States.D = 0;
	data->States.yold = 0;
	data->Par.K = 4.4;
	data->Par.Ti = 0.4;
	data->Par.Td = 0.2;
	data->Par.Tt = 10;
	data->Par.N = 10;
	data->Par.b = 1;
	data->Par.ulow = -1;
	data->Par.uhigh = 1;
	data->Par.h = 0.03;
	data->Par.bi = data->Par.K * data->Par.h/data->Par.Ti;
	data->Par.ar = data->Par.h/data->Par.Tt;
	data->Par.bd = data->Par.K * data->Par.N*data->Par.Td/(data->Par.Td +data->Par.N * data->Par.h );
	data->Par.ad = data->Par.Td/(data->Par.Td+data->Par.N*data->Par.h);

}

void PID_CalculateOutput(struct PID_Data *data)
{
	
	double P;
	//Proportional part
	P= data->Par.K*(data->Par.b * data->Signals.uc - data->Signals.y);

	//Derivative part
	data->States.D = data->Par.ad * data->States.D - data->Par.bd * (data->Signals.y-data->States.yold);

	//Calculate Control Signal
	data->Signals.v = P+data->States.I + data->States.D;

	//Handel acturator limitations
	if(data->Signals.v < data->Par.ulow)
	{
		data->Signals.u = data->Par.ulow;
	} else if(data->Signals.v > data->Par.uhigh){
		data->Signals.u = data->Par.uhigh;
	}else{
		data->Signals.u = data->Signals.v;
	}
	


}

void PID_UpdateStates(struct PID_Data *data)
{
	data->States.I = data->States.I + data->Par.bi * (data->Signals.uc - data->Signals.y) + data->Par.ar * (data->Signals.u - data->Signals.v);

	data->States.yold = data->Signals.y;

 	}
