#ifndef analog_read_H_
#define analog_read_H_

void ADC1_INIT(void);

#endif /* PWM_H_ */